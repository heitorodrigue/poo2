using System.Windows;

namespace Sniper_the_Dummies_WPF_MOO_ICT
{
    public partial class PauseWindow : Window
    {
        public bool ContinueGame { get; private set; } = false;

        public PauseWindow(int score)
        {
            InitializeComponent();
            scoreText.Text = $"Pontua��o Atual: {score}";
        }

        private void Continue_Click(object sender, RoutedEventArgs e)
        {
            ContinueGame = true;
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
