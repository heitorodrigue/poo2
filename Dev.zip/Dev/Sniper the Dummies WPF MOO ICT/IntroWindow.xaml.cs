using System.Windows;

namespace Sniper_the_Dummies_WPF_MOO_ICT
{
    public partial class IntroWindow : Window
    {
        public string SelectedMode { get; private set; } = string.Empty;


        public IntroWindow()
        {
            InitializeComponent();
        }

        private void EasyButton_Click(object sender, RoutedEventArgs e)
        {
            SelectedMode = "Facil";
            this.DialogResult = true;
        }

        private void NormalButton_Click(object sender, RoutedEventArgs e)
        {
            SelectedMode = "Normal";
            this.DialogResult = true;
        }

        private void HardButton_Click(object sender, RoutedEventArgs e)
        {
            SelectedMode = "Dificil";
            this.DialogResult = true;
        }
    }
}
